package com.example.eggtimer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SeekBar seekBar;
    TextView textView;
    boolean check = true;
    Button go;
    CountDownTimer countDownTimer;

    public void buttonTapped(View view)
    {
        if(check) {
            check = false;
            seekBar.setEnabled(false);
            go.setText("Stop");
            countDownTimer = new CountDownTimer(seekBar.getProgress() * 1000 + 100, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    update((int) millisUntilFinished / 1000);
                }

                @Override
                public void onFinish() {
                    textView.setText("0:00");
                    MediaPlayer mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.horn);
                    mediaPlayer.start();
                    reset();
                }
            }.start();
        }
        else
        {
            reset();
        }
    }

    public void reset()
    {
        check = true;
        seekBar.setProgress(30);
        textView.setText("0:30");
        go.setText("go");
        seekBar.setEnabled(true);
        countDownTimer.cancel();
    }
    public void update(int secLeft)
    {
        int min = secLeft/60;
        int sec = secLeft - min*60;
        String secString = Integer.toString(sec);
        if(sec <= 9)
        {
            secString = "0" + Integer.toString(sec);
        }
        textView.setText(Integer.toString(min) + ":" + secString);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBar.setMax(600);
        seekBar.setProgress(30);

        textView = (TextView) findViewById(R.id.timer);

        go = (Button) findViewById(R.id.controlButton);

        //new CountDownTimer(p,1000)
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                update(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}